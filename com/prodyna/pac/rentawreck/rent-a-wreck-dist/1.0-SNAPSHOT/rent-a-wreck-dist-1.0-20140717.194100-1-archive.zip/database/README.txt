1. Use Schema to create database
	raw-schema-0-to-1.0-SNAPSHOT.sql
	
2. Use Data Import Script to create minimal set of Roles and Administrator User (username: admin / password: admin)
	initial-data.sql